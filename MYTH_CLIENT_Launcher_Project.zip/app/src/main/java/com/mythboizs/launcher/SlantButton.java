package com.mythboizs.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** Cut-corner eSports button. Primary = red gradient, secondary = dark with red outline. */
public class SlantButton extends View {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final boolean primary;
    private final String label;
    private final String sub;
    private final float d;

    public SlantButton(Context c, String label, String sub, boolean primary) {
        super(c);
        this.label = label;
        this.sub = sub;
        this.primary = primary;
        this.d = c.getResources().getDisplayMetrics().density;
        setClickable(true);
        setFocusable(true);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.5f * d);
        stroke.setColor(Color.parseColor("#FF2D3D"));
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), Math.round((primary ? 76 : 62) * d));
    }

    @Override
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float cut = 16 * d;
        float inset = 1.5f * d;

        path.reset();
        path.moveTo(cut, inset);
        path.lineTo(w - inset, inset);
        path.lineTo(w - inset, h - cut);
        path.lineTo(w - cut, h - inset);
        path.lineTo(inset, h - inset);
        path.lineTo(inset, cut);
        path.close();

        fill.setStyle(Paint.Style.FILL);
        if (primary) {
            fill.setShader(new LinearGradient(0, 0, w, 0, Color.parseColor("#FF2D3D"),
                    Color.parseColor("#A80019"), Shader.TileMode.CLAMP));
        } else {
            fill.setShader(null);
            fill.setColor(Color.parseColor("#14141C"));
        }
        fill.setAlpha(isPressed() ? 170 : 255);
        c.drawPath(path, fill);
        if (!primary) {
            c.drawPath(path, stroke);
            fill.setShader(null);
            fill.setColor(Color.parseColor("#FF2D3D"));
            c.drawRect(inset, cut, inset + 4 * d, h - inset - cut * 0.2f, fill);
        }

        text.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        text.setColor(Color.WHITE);
        text.setLetterSpacing(0.08f);
        text.setTextSize((primary ? 24 : 17) * d);
        float x = 24 * d;
        float baseline;
        if (sub == null || sub.length() == 0) {
            Paint.FontMetrics fm = text.getFontMetrics();
            baseline = h / 2f - (fm.ascent + fm.descent) / 2f;
        } else {
            baseline = h * 0.47f;
        }
        c.drawText(label, x, baseline, text);

        if (sub != null && sub.length() > 0) {
            text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            text.setLetterSpacing(0.02f);
            text.setTextSize(11.5f * d);
            text.setColor(primary ? Color.parseColor("#FFD3D8") : Color.parseColor("#8B8B99"));
            c.drawText(sub, x, h * 0.74f, text);
        }

        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setLetterSpacing(0f);
        text.setColor(primary ? Color.WHITE : Color.parseColor("#FF2D3D"));
        text.setTextSize(26 * d);
        c.drawText("›", w - 40 * d, h / 2f + 9 * d, text);
    }
}
