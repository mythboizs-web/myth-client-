package com.mythboizs.launcher;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final String MC_RELEASE = "com.mojang.minecraftpe";
    private static final String MC_PREVIEW = "com.mojang.minecraftpe.preview";
    private static final String AUTHORITY = "com.mythboizs.launcher.share";
    private static final String BUNDLED_PACK = "MYTH_CLIENT.mcaddon";
    private static final int REQ_PICK = 42;

    private static final String RED = "#FF2D3D";
    private static final String BG = "#0A0A0F";
    private static final String PANEL = "#14141C";
    private static final String MUTED = "#8B8B99";

    private TextView statusText;
    private View statusDot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor(BG));
        getWindow().setNavigationBarColor(Color.parseColor(BG));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor(BG));
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        root.addView(new HeaderView(this), new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // status pill
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(14), dp(12), dp(14), dp(12));
        pill.setBackground(box(PANEL, null, 6));
        statusDot = new View(this);
        GradientDrawable dot = new GradientDrawable();
        dot.setShape(GradientDrawable.OVAL);
        dot.setColor(Color.parseColor(MUTED));
        statusDot.setBackground(dot);
        pill.addView(statusDot, new LinearLayout.LayoutParams(dp(10), dp(10)));
        statusText = label("", 12, "#FFFFFF", true, 0.18f);
        statusText.setPadding(dp(12), 0, 0, 0);
        pill.addView(statusText);
        body.addView(pill, margins(0, 0, 0, 16));

        SlantButton launch = new SlantButton(this, "LAUNCH GAME", "Open Minecraft with MYTH CLIENT ready", true);
        launch.setOnClickListener(v -> launchMinecraft());
        body.addView(launch, margins(0, 0, 0, 12));

        SlantButton install = new SlantButton(this, "INSTALL CLIENT PACK", "Resource pack + menu addon", false);
        install.setOnClickListener(v -> installBundled());
        body.addView(install, margins(0, 0, 0, 10));

        SlantButton imp = new SlantButton(this, "IMPORT FILE", ".mcaddon  .mcpack  .mcworld", false);
        imp.setOnClickListener(v -> pickFile());
        body.addView(imp, margins(0, 0, 0, 22));

        body.addView(section("FEATURES"), margins(0, 0, 0, 10));
        LinearLayout row1 = chipRow("LOW FIRE", "COORDS", "DIRECTION");
        LinearLayout row2 = chipRow("COMBO COUNTER", "TIME + DAY", "DEATH POS");
        body.addView(row1, margins(0, 0, 0, 8));
        body.addView(row2, margins(0, 0, 0, 22));

        body.addView(section("SETUP"), margins(0, 0, 0, 10));
        body.addView(step("1", "Install the pack", "Tap INSTALL CLIENT PACK and let Minecraft import it."), margins(0, 0, 0, 8));
        body.addView(step("2", "Activate in your world", "World settings: enable MYTH CLIENT UI (resource) and MYTH CLIENT Menu (behavior)."), margins(0, 0, 0, 8));
        body.addView(step("3", "Open the menu", "Hold a Clock and use it in game to open the client menu."), margins(0, 0, 0, 8));
        body.addView(step("4", "HUD mods (optional)", "Import the BedrockTools levipack in LeviLauncher for keystrokes, CPS, zoom and more."), margins(0, 0, 0, 24));

        TextView foot = label("MYTH CLIENT  v1.0   •   MADE BY SAHIL   •   MYTH BOIZS", 10, "#5C5C6B", false, 0.16f);
        foot.setGravity(Gravity.CENTER);
        body.addView(foot);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String pkg = installedMinecraft();
        GradientDrawable dot = (GradientDrawable) statusDot.getBackground();
        if (pkg == null) {
            dot.setColor(Color.parseColor(RED));
            statusText.setText("MINECRAFT NOT FOUND");
            statusText.setTextColor(Color.parseColor("#FF8A94"));
        } else {
            dot.setColor(Color.parseColor("#2BFF88"));
            statusText.setText("MINECRAFT READY" + (pkg.equals(MC_PREVIEW) ? "  •  PREVIEW" : ""));
            statusText.setTextColor(Color.parseColor("#B8FFD6"));
        }
    }

    // ---------- Minecraft helpers ----------
    private String installedMinecraft() {
        PackageManager pm = getPackageManager();
        for (String p : new String[]{MC_RELEASE, MC_PREVIEW}) {
            try {
                pm.getPackageInfo(p, 0);
                return p;
            } catch (PackageManager.NameNotFoundException ignored) {
            }
        }
        return null;
    }

    private void launchMinecraft() {
        String pkg = installedMinecraft();
        if (pkg == null) {
            toast("Minecraft is not installed");
            return;
        }
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) {
            toast("Could not open Minecraft");
            return;
        }
        startActivity(i);
    }

    private void openInMinecraft(Uri uri) {
        String pkg = installedMinecraft();
        if (pkg == null) {
            toast("Minecraft is not installed");
            return;
        }
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(uri, "application/octet-stream");
        i.setPackage(pkg);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("Minecraft could not open this file");
        }
    }

    private void installBundled() {
        try {
            File dir = new File(getCacheDir(), "share");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("mkdir failed");
            File out = new File(dir, BUNDLED_PACK);
            try (InputStream in = getAssets().open(BUNDLED_PACK);
                 OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            }
            openInMinecraft(Uri.parse("content://" + AUTHORITY + "/" + BUNDLED_PACK));
        } catch (IOException e) {
            toast("Pack copy failed: " + e.getMessage());
        }
    }

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            openInMinecraft(data.getData());
        }
    }

    // ---------- UI helpers ----------
    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView label(String s, int sp, String color, boolean bold, float spacing) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(Color.parseColor(color));
        t.setLetterSpacing(spacing);
        if (bold) t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        return t;
    }

    private GradientDrawable box(String fillColor, String strokeColor, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor(fillColor));
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != null) g.setStroke(dp(1), Color.parseColor(strokeColor));
        return g;
    }

    private LinearLayout.LayoutParams margins(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private View section(String title) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        View bar = new View(this);
        bar.setBackgroundColor(Color.parseColor(RED));
        row.addView(bar, new LinearLayout.LayoutParams(dp(4), dp(16)));
        TextView t = label(title, 13, "#FFFFFF", true, 0.3f);
        t.setPadding(dp(10), 0, 0, 0);
        row.addView(t);
        return row;
    }

    private LinearLayout chipRow(String a, String b, String c) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] items = {a, b, c};
        for (int i = 0; i < items.length; i++) {
            TextView chip = label(items[i], 10, "#FFD3D8", true, 0.12f);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(4), dp(10), dp(4), dp(10));
            chip.setBackground(box("#1A0E12", "#5A1A24", 4));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.setMargins(dp(8), 0, 0, 0);
            row.addView(chip, lp);
        }
        return row;
    }

    private View step(String num, String title, String body) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(14), dp(12), dp(14), dp(12));
        row.setBackground(box(PANEL, null, 6));

        TextView n = label(num, 22, RED, true, 0f);
        n.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        n.setGravity(Gravity.CENTER);
        row.addView(n, new LinearLayout.LayoutParams(dp(30), ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), 0, 0, 0);
        col.addView(label(title.toUpperCase(), 12, "#FFFFFF", true, 0.12f));
        TextView b = label(body, 12, MUTED, false, 0f);
        b.setPadding(0, dp(3), 0, 0);
        col.addView(b);
        row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
