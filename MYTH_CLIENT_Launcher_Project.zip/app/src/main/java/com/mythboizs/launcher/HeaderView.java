package com.mythboizs.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** eSports style banner: dark base, red slashes, big italic MYTH CLIENT wordmark. */
public class HeaderView extends View {

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float d;

    public HeaderView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        setMeasuredDimension(MeasureSpec.getSize(wSpec), Math.round(200 * d));
    }

    private void slash(Canvas c, float x, float w, float skew, float h, int color) {
        path.reset();
        path.moveTo(x + skew, 0);
        path.lineTo(x + skew + w, 0);
        path.lineTo(x + w, h);
        path.lineTo(x, h);
        path.close();
        p.setShader(null);
        p.setColor(color);
        c.drawPath(path, p);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();

        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, w, h, Color.parseColor("#0B0B10"),
                Color.parseColor("#1C0A10"), Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, p);

        float sk = 70 * d;
        slash(c, w * 0.60f, 44 * d, sk, h, Color.parseColor("#FF2D3D"));
        slash(c, w * 0.60f + 56 * d, 18 * d, sk, h, Color.parseColor("#B3001B"));
        slash(c, w * 0.60f + 82 * d, 8 * d, sk, h, Color.parseColor("#661020"));

        // bottom accent line
        p.setShader(new LinearGradient(0, 0, w, 0, Color.parseColor("#FF2D3D"),
                Color.parseColor("#00000000"), Shader.TileMode.CLAMP));
        c.drawRect(0, h - 3 * d, w, h, p);
        p.setShader(null);

        float left = 24 * d;

        p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC));
        p.setLetterSpacing(0.04f);
        p.setTextSize(66 * d);
        p.setColor(Color.parseColor("#000000"));
        c.drawText("MYTH", left + 2 * d, 92 * d + 2 * d, p);
        p.setColor(Color.WHITE);
        c.drawText("MYTH", left, 92 * d, p);

        p.setTextSize(40 * d);
        p.setLetterSpacing(0.32f);
        p.setColor(Color.parseColor("#FF2D3D"));
        c.drawText("CLIENT", left, 136 * d, p);

        p.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        p.setTextSize(11 * d);
        p.setLetterSpacing(0.28f);
        p.setColor(Color.parseColor("#8B8B99"));
        c.drawText("COMPETITIVE  •  MCPE  •  BY MYTH BOIZS", left, 168 * d, p);
        p.setLetterSpacing(0f);
    }
}
